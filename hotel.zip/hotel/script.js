const totalTables = 20;
const tableLayout = document.getElementById('tableLayout');
const tableSelect = document.getElementById('tableNumber');
let bookedTables = JSON.parse(localStorage.getItem('bookedTables')) || [];
let users = JSON.parse(localStorage.getItem('users')) || {};
let cart = JSON.parse(localStorage.getItem('cart')) || [];

const userBtn = document.getElementById('userBtn');
const cartBtn = document.getElementById('cartBtn');
const cartDropdown = document.getElementById('cartDropdown');
const cartItems = document.getElementById('cartItems');
const cartEmpty = document.getElementById('cartEmpty');
const authModal = document.getElementById('authModal');
const closeBtn = document.querySelector('.close');
let currentUser = localStorage.getItem('currentUser') || null;

// Initialize navbar and cart
if (currentUser) {
    userBtn.querySelector('span').textContent = currentUser;
} else {
    document.querySelector('.booking-section').classList.add('login-required');
}

if (cart.length > 0) {
    cartBtn.querySelector('span').textContent = `Cart (${cart.length})`;
    updateCartDisplay();
} else {
    cartEmpty.style.display = 'block';
}

userBtn.addEventListener('click', () => {
    authModal.style.display = 'block';
});

cartBtn.addEventListener('click', (e) => {
    e.preventDefault();
    cartDropdown.style.display = cartDropdown.style.display === 'block' ? 'none' : 'block';
});

closeBtn.addEventListener('click', () => {
    authModal.style.display = 'none';
});

window.addEventListener('click', (e) => {
    if (e.target === authModal) {
        authModal.style.display = 'none';
    }
    if (!cartBtn.contains(e.target) && !cartDropdown.contains(e.target)) {
        cartDropdown.style.display = 'none';
    }
});

const tabButtons = document.querySelectorAll('.tab-btn');
const authForms = document.querySelectorAll('.auth-form');

tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        tabButtons.forEach(b => b.classList.remove('active'));
        authForms.forEach(f => f.classList.remove('active'));
        
        btn.classList.add('active');
        document.getElementById(`${btn.dataset.tab}Form`).classList.add('active');
    });
});

document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = e.target[0].value;
    const password = e.target[1].value;
    
    if (users[email] && users[email].password === password) {
        currentUser = users[email].name;
        localStorage.setItem('currentUser', currentUser);
        userBtn.querySelector('span').textContent = currentUser;
        authModal.style.display = 'none';
        document.querySelector('.booking-section').classList.remove('login-required');
        alert('Login successful!');
    } else {
        alert('Invalid credentials');
    }
});

document.getElementById('registerForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = e.target[0].value;
    const email = e.target[1].value;
    const password = e.target[2].value;
    
    if (users[email]) {
        alert('Email already registered');
        return;
    }
    
    users[email] = { name, password };
    localStorage.setItem('users', JSON.stringify(users));
    alert('Registration successful! Please login.');
    tabButtons[0].click();
});

function generateTables() {
    tableLayout.innerHTML = '';
    tableSelect.innerHTML = '<option value="">Select Table</option>';
    
    for (let i = 1; i <= totalTables; i++) {
        const tableDiv = document.createElement('div');
        tableDiv.className = 'table';
        tableDiv.textContent = i;
        tableDiv.dataset.table = i;
        if (bookedTables.includes(i)) {
            tableDiv.classList.add('booked');
        }
        tableLayout.appendChild(tableDiv);

        if (!bookedTables.includes(i)) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = `Table ${i}`;
            tableSelect.appendChild(option);
        }
    }
}

generateTables();

const bookingForm = document.getElementById('bookingForm');
bookingForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    if (!currentUser) {
        alert('Please login to book a table');
        authModal.style.display = 'block';
        return;
    }
    
    const tableNum = parseInt(document.getElementById('tableNumber').value);
    if (!tableNum) {
        alert('Please select a table');
        return;
    }

    const bookingData = {
        name: document.getElementById('name').value,
        date: document.getElementById('date').value,
        time: document.getElementById('time').value,
        table: tableNum,
        user: currentUser
    };

    bookedTables.push(tableNum);
    localStorage.setItem('bookedTables', JSON.stringify(bookedTables));
    localStorage.setItem('lastBooking', JSON.stringify(bookingData));

    alert(`Table ${tableNum} reserved successfully!\nName: ${bookingData.name}\nDate: ${bookingData.date}\nTime: ${bookingData.time}`);
    bookingForm.reset();
    generateTables();
});

tableLayout.addEventListener('click', (e) => {
    const table = e.target.closest('.table');
    if (!currentUser) {
        alert('Please login to book a table');
        authModal.style.display = 'block';
        return;
    }
    if (table && !table.classList.contains('booked')) {
        tableSelect.value = table.dataset.table;
        table.classList.add('selected');
        
        setTimeout(() => {
            table.classList.remove('selected');
        }, 500);
    }
});

// Order Food Functionality
const addToCartButtons = document.querySelectorAll('.add-to-cart');
addToCartButtons.forEach(button => {
    button.addEventListener('click', (e) => {
        if (!currentUser) {
            alert('Please login to add items to cart');
            authModal.style.display = 'block';
            return;
        }

        const foodItem = e.target.closest('.food-item');
        const itemName = foodItem.querySelector('h3').textContent;
        const itemPrice = foodItem.querySelector('p').textContent;

        cart.push({ name: itemName, price: itemPrice });
        localStorage.setItem('cart', JSON.stringify(cart));
        cartBtn.querySelector('span').textContent = `Cart (${cart.length})`;
        updateCartDisplay();
        alert(`${itemName} added to cart!`);
    });
});

function updateCartDisplay() {
    cartItems.innerHTML = '';
    if (cart.length === 0) {
        cartEmpty.style.display = 'block';
        cartBtn.querySelector('span').textContent = 'Cart';
    } else {
        cartEmpty.style.display = 'none';
        cart.forEach((item, index) => {
            const li = document.createElement('li');
            li.innerHTML = `${item.name} - ${item.price} <button onclick="removeFromCart(${index})">Remove</button>`;
            cartItems.appendChild(li);
        });
    }
}

function removeFromCart(index) {
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    cartBtn.querySelector('span').textContent = `Cart (${cart.length})`;
    updateCartDisplay();
    alert('Item removed from cart!');
}

// Make removeFromCart globally accessible
window.removeFromCart = removeFromCart;